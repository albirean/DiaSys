﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DialogController : MonoBehaviour
{
    [SerializeField] DialogModel[] Conversation = null;
    [SerializeField] QuestionModel Choice = null;
    [SerializeField] DialogView DialogView = null;
    private int ConversationPoint = 0;
    private int maxConvoPoint = 0;

    private void Awake()
    {
        maxConvoPoint = Conversation.Length;
        DialogView.Clear();
        DialogView.choiceButton.gameObject.SetActive(false);
    }
    private void Update()
    {
        if (ConversationPoint == maxConvoPoint)
        {
            ConversationPoint = maxConvoPoint;
        }

        if (Input.GetKeyDown(KeyCode.Space))
            {
            ConversationPoint = 0;
            DialogView.Display(Conversation[ConversationPoint]);
            ConversationPoint += 1;
            if(ConversationPoint == Conversation.Length)
            {
                DialogView.DisplayChoice(Choice);
                Debug.Log("Display Choices.");
            }
    }

        if (Input.GetKeyDown(KeyCode.Z))
        {
            DialogView.Clear();
        }
    }
}
