﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class DialogView : MonoBehaviour
{

    [SerializeField] Text _nameUIText = null;
    [SerializeField] Text _bodyUIText = null;
    [SerializeField] Image _charaPortrait = null;

    [SerializeField] GameObject _choiceButton = null;
    [SerializeField] Canvas _choicePanel = null;
    [SerializeField] Vector3 ButtonSpacing = new Vector3(0,4,0);

    public GameObject choiceButton
    {
        get { return _choiceButton; }
        private set { _choiceButton = value; }
    }
    [SerializeField] Image _playerPortrait = null;

    public void Display(DialogModel data)
    {
        _nameUIText.text = data.CharaName;
        _bodyUIText.text = data.Dialog;
        _charaPortrait.sprite = data.SpeakerName;
    }

    public void DisplayChoice(QuestionModel choice)
    {
        for (int i = 0; i < choice.Choices.Length; i++) {
            int closureIndex = i;
            _choiceButton.gameObject.SetActive(true);
            GameObject choiceButtons = Instantiate(_choiceButton);
            choiceButtons.transform.SetParent(_choicePanel.transform, false);
            choiceButtons.transform.position += (ButtonSpacing * i);

            choiceButtons.GetComponentInChildren<Text>().text = choice.Choices[i];
            choiceButtons.GetComponentInChildren<Button>().onClick.AddListener(() => AdvanceConversation(closureIndex, choice));
            choiceButtons.GetComponentInChildren<Button>().onClick.AddListener(() => ClearChoices());
        }
        _playerPortrait.sprite = choice.PlayerReaction;
    }
    
    public void ClearChoices()
    {
        _choicePanel.gameObject.SetActive(false);
    }
    public void AdvanceConversation(int buttonIndex, QuestionModel choices)
    {
        int t = buttonIndex;
        DialogModel NextConvo = choices.ConversationsToGoTo[t];
        Display(NextConvo);
        
        Debug.Log("This is button #" + buttonIndex);
    }

    public void Clear()
    {
        _nameUIText.text = "";
        _bodyUIText.text = "";
        _charaPortrait.sprite = null;
    }

    public void Hide()
    {
        //TODO
    }
}
