﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "NewDialogModel", menuName = "Conversation/Dialog")]
public class DialogModel : ScriptableObject
{
    [SerializeField] string _dialog = "...";
    public string Dialog
    {
        get { return _dialog; }
        private set { _dialog = value; }
    }

    [SerializeField] string _charaName;
    public string CharaName
    {
        get { return _charaName; }
        private set { _charaName = value; }
    }

    public Sprite SpeakerName = null;

}
