﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[CreateAssetMenu(fileName = "NewQuestionModel", menuName = "Conversation/Question")]
public class QuestionModel : ScriptableObject
{
    public Sprite PlayerReaction = null;

    public string[] Choices;
    public DialogModel[] ConversationsToGoTo;
}
